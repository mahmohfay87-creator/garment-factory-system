import { useMemo, useState } from "react";
import { Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  deadlineInfo,
  formatDate,
  isActiveOrder,
  ORDER_STATUSES,
  PRIORITIES,
  CLIENT_TYPES,
  type Tone,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import { OrderFormSheet } from "@/components/forms";
import { EmptyState, PageHeader, StatusBadge, ToneText } from "@/components/ui-bits";

function priorityTone(p: string): Tone {
  if (p === "عالية") return "danger";
  if (p === "متوسطة") return "warn";
  return "muted";
}

export function OrdersPage({ onOpenOrder }: { onOpenOrder: (id: string) => void }) {
  const { orders } = useStore();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("الكل");
  const [priorityFilter, setPriorityFilter] = useState("الكل");
  const [typeFilter, setTypeFilter] = useState("الكل");
  const [scope, setScope] = useState<"الكل" | "النشطة">("الكل");
  const [formOpen, setFormOpen] = useState(false);

  const filtered = useMemo(() => {
    return orders
      .filter((o) => (scope === "النشطة" ? isActiveOrder(o) : true))
      .filter((o) => (statusFilter === "الكل" ? true : o.status === statusFilter))
      .filter((o) => (priorityFilter === "الكل" ? true : o.priority === priorityFilter))
      .filter((o) => (typeFilter === "الكل" ? true : o.clientType === typeFilter))
      .filter((o) => {
        if (!query.trim()) return true;
        const q = query.trim();
        return (
          o.id.includes(q) ||
          o.client.includes(q) ||
          o.product.includes(q) ||
          o.specs.includes(q)
        );
      })
      .sort((a, b) => a.deliveryDate.localeCompare(b.deliveryDate));
  }, [orders, query, statusFilter, priorityFilter, typeFilter, scope]);

  const selCls =
    "h-10 cursor-pointer rounded-lg border border-input bg-popover/80 px-3 text-[14px] outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/25";

  return (
    <div>
      <PageHeader
        title="تسجيل الطلبيات"
        subtitle={`${orders.length} طلبية مسجلة — اضغط على أي صف لعرض التفاصيل ومراحل الإنتاج`}
        actions={
          <Button onClick={() => setFormOpen(true)}>
            <Plus className="me-1.5 size-4" />
            طلبية جديدة
          </Button>
        }
      />

      {/* شريط الفلاتر */}
      <div className="surface mb-4 flex flex-wrap items-center gap-2 px-3 py-3">
        <div className="relative min-w-[200px] flex-1">
          <Search className="absolute end-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث برقم الطلب أو اسم العميل أو المنتج…"
            className="h-10 w-full rounded-lg border border-input bg-popover/80 pe-9 ps-3 text-[14px] outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-primary/25"
          />
        </div>
        <select value={scope} onChange={(e) => setScope(e.target.value as typeof scope)} className={selCls}>
          <option value="الكل">كل الطلبيات</option>
          <option value="النشطة">النشطة فقط</option>
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={selCls}>
          <option value="الكل">كل الحالات</option>
          {ORDER_STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)} className={selCls}>
          <option value="الكل">كل الأولويات</option>
          {PRIORITIES.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
        <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className={selCls}>
          <option value="الكل">جملة + قطاعي</option>
          {CLIENT_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      <div className="surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="ruled-table min-w-[900px]">
            <thead>
              <tr>
                <th>رقم الطلب</th>
                <th>تاريخ الطلب</th>
                <th>اسم العميل</th>
                <th>النوع</th>
                <th>المنتج</th>
                <th>الكمية</th>
                <th>التسليم المطلوب</th>
                <th>المتبقي</th>
                <th>الأولوية</th>
                <th>حالة الطلب</th>
                <th>تنبيه الموعد</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => {
                const a = deadlineInfo(o);
                return (
                  <tr key={o.id} data-clickable onClick={() => onOpenOrder(o.id)} title="عرض التفاصيل">
                    <td className="num font-bold" dir="ltr">
                      {o.id}
                    </td>
                    <td className="num whitespace-nowrap">{formatDate(o.date)}</td>
                    <td className="min-w-[150px] font-medium">{o.client}</td>
                    <td>{o.clientType}</td>
                    <td>{o.product}</td>
                    <td className="num font-semibold">{o.quantity}</td>
                    <td className="num whitespace-nowrap">{formatDate(o.deliveryDate)}</td>
                    <td>
                      <ToneText tone={a.tone}>
                        {a.days === null
                          ? a.label
                          : a.days < 0
                            ? `متأخرة ${Math.abs(a.days)} يوم`
                            : `${a.days} يوم`}
                      </ToneText>
                    </td>
                    <td>
                      <StatusBadge label={o.priority} tone={priorityTone(o.priority)} />
                    </td>
                    <td>{o.status}</td>
                    <td>
                      <StatusBadge label={a.label} tone={a.tone} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 ? (
          <EmptyState title="لا توجد طلبيات مطابقة" hint="جرّب تغيير الفلاتر أو سجّل طلبية جديدة" />
        ) : null}
      </div>

      <OrderFormSheet open={formOpen} onOpenChange={setFormOpen} editing={null} />
    </div>
  );
}
