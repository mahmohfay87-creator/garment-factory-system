import { useMemo, useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  formatDate,
  STAGE_PIPELINE,
  STAGE_STATUSES,
  stageProgress,
  type ProductionStage,
  type StageStatus,
  type Tone,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import { StageFormSheet } from "@/components/forms";
import { EmptyState, PageHeader, ProgressBar, StatusBadge } from "@/components/ui-bits";

function stageTone(s: StageStatus): Tone {
  if (s === "متوقفة") return "danger";
  if (s === "جارية") return "ok";
  if (s === "مكتملة") return "done";
  return "muted";
}

export function ProductionPage() {
  const { stages, orders, saveStage, deleteStage } = useStore();
  const [stageFilter, setStageFilter] = useState("الكل");
  const [statusFilter, setStatusFilter] = useState("الكل");
  const [form, setForm] = useState<{ open: boolean; editing: ProductionStage | null }>({
    open: false,
    editing: null,
  });
  const [toDelete, setToDelete] = useState<ProductionStage | null>(null);

  const orderName = (id: string) => orders.find((o) => o.id === id)?.client ?? id;

  const filtered = useMemo(
    () =>
      stages
        .filter((s) => (stageFilter === "الكل" ? true : s.stage === stageFilter))
        .filter((s) => (statusFilter === "الكل" ? true : s.status === statusFilter))
        .sort((a, b) => a.orderId.localeCompare(b.orderId) || a.startDate.localeCompare(b.startDate)),
    [stages, stageFilter, statusFilter],
  );

  const activeOrders = orders.filter((o) => o.status !== "مكتملة" && o.status !== "ملغاة");

  const selCls =
    "h-10 cursor-pointer rounded-lg border border-input bg-popover/80 px-3 text-[14px] outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/25";

  return (
    <div>
      <PageHeader
        title="مراحل الإنتاج"
        subtitle="تابع مسار كل طلبية عبر خط الإنتاج — من استلام الخامات حتى التغليف"
        actions={
          <Button onClick={() => setForm({ open: true, editing: null })}>
            <Plus className="me-1.5 size-4" />
            إضافة مرحلة
          </Button>
        }
      />

      {/* تقدم الطلبيات النشطة */}
      <div className="mb-5 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {activeOrders.map((o) => {
          const p = stageProgress(o.id, stages);
          return (
            <div key={o.id} className="surface px-4 py-3">
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <span className="num text-[13px] font-bold" dir="ltr">
                  {o.id}
                </span>
                <span className="truncate text-[13px] text-muted-foreground">{o.client}</span>
                <span className="num text-[13px] font-semibold">
                  {p.done}/{p.total || "—"}
                </span>
              </div>
              <ProgressBar pct={p.pct} tone={p.pct === 100 ? "done" : "ok"} />
              <div className="num mt-1 text-[11.5px] text-muted-foreground">
                {p.total === 0 ? "لا توجد مراحل مسجلة" : `${p.pct}% مكتمل`}
              </div>
            </div>
          );
        })}
        {activeOrders.length === 0 ? (
          <p className="text-[13.5px] text-muted-foreground">لا توجد طلبيات نشطة حاليًا.</p>
        ) : null}
      </div>

      <div className="surface mb-4 flex flex-wrap items-center gap-2 px-3 py-3">
        <select value={stageFilter} onChange={(e) => setStageFilter(e.target.value)} className={selCls}>
          <option value="الكل">كل المراحل</option>
          {STAGE_PIPELINE.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={selCls}>
          <option value="الكل">كل الحالات</option>
          {STAGE_STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <span className="ms-auto text-[12.5px] text-muted-foreground">
          اضغط على شارة الحالة في الجدول للتنقل بين الحالات
        </span>
      </div>

      <div className="surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="ruled-table min-w-[860px]">
            <thead>
              <tr>
                <th>رقم الطلب</th>
                <th>العميل</th>
                <th>المرحلة</th>
                <th>تاريخ البدء</th>
                <th>الانتهاء المتوقع</th>
                <th>حالة المرحلة</th>
                <th>المسؤول</th>
                <th>ملاحظات</th>
                <th>إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.id}>
                  <td className="num font-bold" dir="ltr">
                    {s.orderId}
                  </td>
                  <td className="min-w-[130px]">{orderName(s.orderId)}</td>
                  <td className="font-medium">{s.stage}</td>
                  <td className="num whitespace-nowrap">{formatDate(s.startDate)}</td>
                  <td className="num whitespace-nowrap">{formatDate(s.endDate)}</td>
                  <td>
                    <button
                      type="button"
                      title="اضغط لتغيير الحالة"
                      onClick={() => {
                        const idx = STAGE_STATUSES.indexOf(s.status);
                        const next = STAGE_STATUSES[(idx + 1) % STAGE_STATUSES.length];
                        saveStage({ ...s, status: next });
                        toast.success(`مرحلة «${s.stage}» أصبحت: ${next}`);
                      }}
                      className="cursor-pointer rounded-full outline-none transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <StatusBadge label={s.status} tone={stageTone(s.status)} />
                    </button>
                  </td>
                  <td>{s.responsible}</td>
                  <td className="max-w-[180px] truncate text-muted-foreground">{s.notes || "—"}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 px-2"
                        onClick={() => setForm({ open: true, editing: s })}
                      >
                        <Pencil className="size-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 px-2 text-destructive hover:text-destructive"
                        onClick={() => setToDelete(s)}
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 ? (
          <EmptyState title="لا توجد مراحل مطابقة" hint="أضف مرحلة إنتاج جديدة لبدء المتابعة" />
        ) : null}
      </div>

      <StageFormSheet
        open={form.open}
        onOpenChange={(v) => setForm((f) => ({ ...f, open: v }))}
        editing={form.editing}
      />

      <AlertDialog open={!!toDelete} onOpenChange={(v) => !v && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف المرحلة؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف مرحلة «{toDelete?.stage}» من الطلبية {toDelete?.orderId} نهائيًا.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (toDelete) {
                  deleteStage(toDelete.id);
                  toast.success("تم حذف المرحلة");
                }
                setToDelete(null);
              }}
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
