import { useState } from "react";
import { Download, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import {
  currentStageOf,
  formatDate,
  formatLongDate,
  isActiveOrder,
  type Tone,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import { EmptyState, PageHeader, StatusBadge } from "@/components/ui-bits";

function stageTone(s: string): Tone {
  if (s === "متوقفة") return "danger";
  if (s === "جارية") return "ok";
  if (s === "مكتملة") return "done";
  return "muted";
}

export function DailyReportPage() {
  const { orders, stages, dailyNotes, saveDailyNote } = useStore();
  const [date, setDate] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  });

  const activeOrders = orders
    .filter(isActiveOrder)
    .sort((a, b) => a.deliveryDate.localeCompare(b.deliveryDate));

  const noteOf = (orderId: string) =>
    dailyNotes.find((n) => n.orderId === orderId && n.date === date)?.note ?? "";

  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const valueFor = (orderId: string) =>
    orderId in drafts ? drafts[orderId] : noteOf(orderId);

  const dirty = Object.entries(drafts).some(
    ([orderId, v]) => v !== noteOf(orderId),
  );

  const saveAll = () => {
    for (const [orderId, note] of Object.entries(drafts)) {
      saveDailyNote(orderId, date, note);
    }
    setDrafts({});
    toast.success("تم حفظ ملاحظات اليوم");
  };

  const exportDay = () => {
    const rows = activeOrders.map((o) => {
      const st = currentStageOf(o.id, stages);
      return {
        "رقم الطلب": o.id,
        "العميل": o.client,
        "المنتج": o.product,
        "الكمية": o.quantity,
        "المرحلة الحالية": st ? st.name : "—",
        "حالة المرحلة": st ? st.status : "—",
        "حالة الطلب": o.status,
        "الأولوية": o.priority,
        "ملاحظات اليوم": noteOf(o.id),
      };
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [
      { wch: 10 },
      { wch: 28 },
      { wch: 16 },
      { wch: 8 },
      { wch: 18 },
      { wch: 12 },
      { wch: 12 },
      { wch: 10 },
      { wch: 40 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "التقرير اليومي");
    XLSX.writeFile(wb, `التقرير_اليومي_${date}.xlsx`);
    toast.success("تم تصدير التقرير بنجاح");
  };

  return (
    <div>
      <PageHeader
        title="التقرير اليومي"
        subtitle="سجّل إنجاز كل طلبية نشطة — تُحفظ الملاحظات مرتبة بتاريخ كل يوم"
        actions={
          <>
            <input
              type="date"
              value={date}
              dir="ltr"
              onChange={(e) => {
                setDate(e.target.value);
                setDrafts({});
              }}
              className="num h-10 cursor-pointer rounded-lg border border-input bg-popover/80 px-3 text-left text-[14px] outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/25"
            />
            <Button variant="outline" onClick={exportDay}>
              <Download className="me-1.5 size-4" />
              تصدير Excel
            </Button>
            <Button onClick={saveAll} disabled={!dirty}>
              <Save className="me-1.5 size-4" />
              حفظ الملاحظات
            </Button>
          </>
        }
      />

      <div className="surface mb-4 flex items-center gap-3 px-4 py-3">
        <p className="text-[14px] font-semibold">تقرير يوم: {formatLongDate(new Date(date + "T00:00:00"))}</p>
        <span className="num ms-auto text-[13px] text-muted-foreground" dir="ltr">
          {activeOrders.length} طلبية نشطة
        </span>
      </div>

      <div className="surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="ruled-table min-w-[920px]">
            <thead>
              <tr>
                <th>رقم الطلب</th>
                <th>العميل</th>
                <th>المنتج</th>
                <th>الكمية</th>
                <th>المرحلة الحالية</th>
                <th>حالة الطلب</th>
                <th>الأولوية</th>
                <th>ملاحظات اليوم</th>
              </tr>
            </thead>
            <tbody>
              {activeOrders.map((o) => {
                const st = currentStageOf(o.id, stages);
                return (
                  <tr key={o.id}>
                    <td className="num font-bold" dir="ltr">
                      {o.id}
                    </td>
                    <td className="min-w-[140px] font-medium">{o.client}</td>
                    <td>{o.product}</td>
                    <td className="num font-semibold">{o.quantity}</td>
                    <td>
                      {st ? (
                        <StatusBadge
                          label={`${st.name} — ${st.status}`}
                          tone={stageTone(st.status)}
                        />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                    <td>{o.status}</td>
                    <td>{o.priority}</td>
                    <td className="min-w-[240px]">
                      <textarea
                        value={valueFor(o.id)}
                        rows={2}
                        placeholder="اكتب إنجاز اليوم هنا…"
                        onChange={(e) =>
                          setDrafts((d) => ({ ...d, [o.id]: e.target.value }))
                        }
                        className="w-full rounded-lg border border-input bg-popover/80 px-3 py-2 text-[13.5px] leading-6 outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/25"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {activeOrders.length === 0 ? (
          <EmptyState title="لا توجد طلبيات نشطة اليوم" />
        ) : null}
      </div>

      <p className="mt-3 text-[12.5px] text-muted-foreground">
        آخر تحديث لحالة المراحل: {formatDate(date)} — اضغط «حفظ الملاحظات» بعد الكتابة، ويمكنك الرجوع لأي يوم سابق من مربع التاريخ.
      </p>
    </div>
  );
}
