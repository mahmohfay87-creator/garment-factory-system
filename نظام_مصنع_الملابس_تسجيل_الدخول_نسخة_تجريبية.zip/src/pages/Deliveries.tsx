import { useMemo, useState } from "react";
import { Truck } from "lucide-react";
import {
  deadlineInfo,
  formatDate,
  isActiveOrder,
  type Tone,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import { EmptyState, PageHeader, StatusBadge, ToneText } from "@/components/ui-bits";

export function DeliveriesPage({ onOpenOrder }: { onOpenOrder: (id: string) => void }) {
  const { orders } = useStore();
  const [scope, setScope] = useState<"القادمة" | "الكل">("القادمة");

  const rows = useMemo(() => {
    const list = orders
      .filter((o) => (scope === "القادمة" ? isActiveOrder(o) : true))
      .map((o) => ({ order: o, alert: deadlineInfo(o) }))
      .sort((a, b) => {
        // المكتملة في النهاية، والباقي حسب تاريخ التسليم
        const aDone = a.order.status === "مكتملة" ? 1 : 0;
        const bDone = b.order.status === "مكتملة" ? 1 : 0;
        if (aDone !== bDone) return aDone - bDone;
        return a.order.deliveryDate.localeCompare(b.order.deliveryDate);
      });
    return list;
  }, [orders, scope]);

  const selCls =
    "h-10 cursor-pointer rounded-lg border border-input bg-popover/80 px-3 text-[14px] outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/25";

  const badge = (tone: Tone, label: string) => <StatusBadge label={label} tone={tone} />;

  return (
    <div>
      <PageHeader
        title="مواعيد التسليم"
        subtitle="كل الطلبيات مرتبة حسب أقرب موعد تسليم — الأعاجل أولًا"
        actions={
          <select value={scope} onChange={(e) => setScope(e.target.value as typeof scope)} className={selCls}>
            <option value="القادمة">التسليمات القادمة</option>
            <option value="الكل">كل الطلبيات</option>
          </select>
        }
      />

      <div className="surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="ruled-table min-w-[820px]">
            <thead>
              <tr>
                <th>رقم الطلب</th>
                <th>العميل</th>
                <th>المنتج</th>
                <th>تاريخ التسليم المطلوب</th>
                <th>حالة الطلب</th>
                <th>الأولوية</th>
                <th>الأيام المتبقية</th>
                <th>حالة الموعد</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ order: o, alert: a }) => (
                <tr key={o.id} data-clickable onClick={() => onOpenOrder(o.id)} title="عرض التفاصيل">
                  <td className="num font-bold" dir="ltr">
                    {o.id}
                  </td>
                  <td className="min-w-[150px] font-medium">{o.client}</td>
                  <td>{o.product}</td>
                  <td className="num whitespace-nowrap">{formatDate(o.deliveryDate)}</td>
                  <td>{o.status}</td>
                  <td>{o.priority}</td>
                  <td>
                    <ToneText tone={a.tone}>
                      {a.days === null
                        ? a.label
                        : a.days < 0
                          ? `متأخرة ${Math.abs(a.days)} يوم`
                          : `${a.days} يوم`}
                    </ToneText>
                  </td>
                  <td>
                    {o.status === "مكتملة"
                      ? badge("done", "تم التسليم")
                      : o.status === "ملغاة"
                        ? badge("muted", "ملغاة")
                        : badge(a.tone, a.label)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {rows.length === 0 ? (
          <EmptyState title="لا توجد تسليمات قادمة" hint="كل الطلبيات مكتملة أو ملغاة" />
        ) : null}
      </div>

      <div className="surface mt-4 flex items-center gap-3 px-4 py-3">
        <Truck className="size-5 shrink-0 text-primary" aria-hidden />
        <p className="text-[13.5px] leading-6 text-muted-foreground">
          نصيحة: راجع صفحة «التقرير اليومي» كل صباح لتسجيل إنجاز كل طلبية قبل موعد التسليم.
        </p>
      </div>
    </div>
  );
}
