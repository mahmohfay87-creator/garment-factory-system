import { useMemo, useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  formatDate,
  MATERIAL_STATUSES,
  materialInfo,
  type MaterialItem,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import { MaterialFormSheet } from "@/components/forms";
import { EmptyState, PageHeader, StatusBadge } from "@/components/ui-bits";

export function MaterialsPage() {
  const { materials, orders, deleteMaterial } = useStore();
  const [kindFilter, setKindFilter] = useState("الكل");
  const [statusFilter, setStatusFilter] = useState("الكل");
  const [orderFilter, setOrderFilter] = useState("الكل");
  const [form, setForm] = useState<{ open: boolean; editing: MaterialItem | null }>({
    open: false,
    editing: null,
  });
  const [toDelete, setToDelete] = useState<MaterialItem | null>(null);

  const filtered = useMemo(
    () =>
      materials
        .filter((m) => (kindFilter === "الكل" ? true : m.kind === kindFilter))
        .filter((m) => (statusFilter === "الكل" ? true : m.status === statusFilter))
        .filter((m) => (orderFilter === "الكل" ? true : m.orderId === orderFilter))
        .sort((a, b) => a.expectedDate.localeCompare(b.expectedDate)),
    [materials, kindFilter, statusFilter, orderFilter],
  );

  const selCls =
    "h-10 cursor-pointer rounded-lg border border-input bg-popover/80 px-3 text-[14px] outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/25";

  return (
    <div>
      <PageHeader
        title="الخامات والإكسسوارات"
        subtitle="تابع طلبات الخامات من الموردين ومواعيد استلامها المتوقعة"
        actions={
          <Button onClick={() => setForm({ open: true, editing: null })}>
            <Plus className="me-1.5 size-4" />
            إضافة خامة
          </Button>
        }
      />

      <div className="surface mb-4 flex flex-wrap items-center gap-2 px-3 py-3">
        <select value={kindFilter} onChange={(e) => setKindFilter(e.target.value)} className={selCls}>
          <option value="الكل">خامات + إكسسوارات</option>
          <option value="خامة">خامات فقط</option>
          <option value="إكسسوار">إكسسوارات فقط</option>
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={selCls}>
          <option value="الكل">كل حالات الاستلام</option>
          {MATERIAL_STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <select value={orderFilter} onChange={(e) => setOrderFilter(e.target.value)} className={selCls}>
          <option value="الكل">كل الطلبيات</option>
          {orders.map((o) => (
            <option key={o.id} value={o.id}>
              {o.id}
            </option>
          ))}
        </select>
      </div>

      <div className="surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="ruled-table min-w-[980px]">
            <thead>
              <tr>
                <th>رقم الطلب</th>
                <th>النوع</th>
                <th>اسم الخامة / الإكسسوار</th>
                <th>الكمية</th>
                <th>المورد</th>
                <th>الاستلام المتوقع</th>
                <th>حالة الاستلام</th>
                <th>الأيام المتبقية</th>
                <th>تنبيه</th>
                <th>إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((m) => {
                const info = materialInfo(m);
                return (
                  <tr key={m.id}>
                    <td className="num font-bold" dir="ltr">
                      {m.orderId}
                    </td>
                    <td>{m.kind}</td>
                    <td className="min-w-[160px] font-medium">{m.name}</td>
                    <td className="num font-semibold">
                      {m.quantity} {m.unit}
                    </td>
                    <td>{m.supplier || "—"}</td>
                    <td className="num whitespace-nowrap">{formatDate(m.expectedDate)}</td>
                    <td>{m.status}</td>
                    <td className="num">
                      {info.days === null ? "—" : info.days < 0 ? `متأخر ${Math.abs(info.days)}` : info.days}
                    </td>
                    <td>
                      <StatusBadge label={info.label} tone={info.tone} />
                    </td>
                    <td>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2"
                          onClick={() => setForm({ open: true, editing: m })}
                        >
                          <Pencil className="size-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-destructive hover:text-destructive"
                          onClick={() => setToDelete(m)}
                        >
                          <Trash2 className="size-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 ? (
          <EmptyState title="لا توجد خامات مطابقة" hint="أضف خامة أو إكسسوارًا لمتابعته" />
        ) : null}
      </div>

      <MaterialFormSheet
        open={form.open}
        onOpenChange={(v) => setForm((f) => ({ ...f, open: v }))}
        editing={form.editing}
      />

      <AlertDialog open={!!toDelete} onOpenChange={(v) => !v && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الخامة؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف «{toDelete?.name}» من الطلبية {toDelete?.orderId} نهائيًا.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (toDelete) {
                  deleteMaterial(toDelete.id);
                  toast.success("تم حذف الخامة");
                }
                setToDelete(null);
              }}
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
