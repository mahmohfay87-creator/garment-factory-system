import {
  AlertTriangle,
  CalendarClock,
  CircleCheckBig,
  ClipboardList,
  Flag,
  Layers,
  Package,
  PackageCheck,
  PackageX,
  Shirt,
  Truck,
  Users,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  dashboardStats,
  deadlineInfo,
  formatLongDate,
  isActiveOrder,
  materialInfo,
  type Tone,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import { PageHeader, StatCard, StatusBadge, ToneText } from "@/components/ui-bits";

export function DashboardPage({ onOpenOrder }: { onOpenOrder: (id: string) => void }) {
  const { data } = useStore();
  const s = dashboardStats(data);

  // طلبيات تحتاج تدخل فوري
  const delayedOrders = data.orders.filter(
    (o) => isActiveOrder(o) && deadlineInfo(o).tone === "danger",
  );
  const approachingOrders = data.orders.filter(
    (o) => isActiveOrder(o) && deadlineInfo(o).tone === "warn",
  );
  const missingMats = data.materials.filter((m) => materialInfo(m).tone === "danger");
  const stopped = data.stages.filter((st) => st.status === "متوقفة");

  const attention = [
    ...delayedOrders.map((o) => ({
      key: o.id,
      text: `الطلبية ${o.id} (${o.client}) — تجاوزت موعد التسليم`,
      tone: "danger" as Tone,
      orderId: o.id,
    })),
    ...approachingOrders.map((o) => ({
      key: o.id,
      text: `الطلبية ${o.id} (${o.client}) — التسليم خلال ${deadlineInfo(o).days} أيام`,
      tone: "warn" as Tone,
      orderId: o.id,
    })),
    ...missingMats.map((m) => ({
      key: m.id,
      text: `${m.kind} «${m.name}» للطلبية ${m.orderId} — ${materialInfo(m).label}`,
      tone: "danger" as Tone,
      orderId: m.orderId,
    })),
    ...stopped.map((st) => ({
      key: st.id,
      text: `مرحلة «${st.stage}» للطلبية ${st.orderId} متوقفة`,
      tone: "danger" as Tone,
      orderId: st.orderId,
    })),
  ];

  const chartData = (() => {
    const map = new Map<string, { product: string; pieces: number; orders: number }>();
    for (const o of data.orders) {
      if (o.status === "ملغاة") continue;
      const cur = map.get(o.product) ?? { product: o.product, pieces: 0, orders: 0 };
      cur.pieces += o.quantity;
      cur.orders += 1;
      map.set(o.product, cur);
    }
    return [...map.values()];
  })();

  return (
    <div>
      <PageHeader
        title="لوحة المتابعة"
        subtitle={`حالة المصنع اليوم — ${formatLongDate()}`}
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
        <StatCard icon={<ClipboardList />} label="إجمالي الطلبيات" value={s.totalOrders} />
        <StatCard icon={<Layers />} label="طلبيات نشطة الآن" value={s.activeOrders} tone="ok" />
        <StatCard icon={<CircleCheckBig />} label="مكتملة" value={s.completedOrders} tone="done" />
        <StatCard icon={<AlertTriangle />} label="متأخرة" value={s.delayed} tone={s.delayed > 0 ? "danger" : "muted"} />
        <StatCard icon={<CalendarClock />} label="اقترب موعدها (٣ أيام)" value={s.approaching} tone={s.approaching > 0 ? "warn" : "muted"} />
        <StatCard icon={<Flag />} label="عالية الأولوية" value={s.highPriority} tone={s.highPriority > 0 ? "danger" : "muted"} />
        <StatCard icon={<Truck />} label="طلبيات جملة" value={s.wholesale} />
        <StatCard icon={<Users />} label="طلبيات قطاعي" value={s.retail} />
        <StatCard icon={<Shirt />} label="إجمالي القطع المطلوبة" value={s.totalPieces} />
        <StatCard icon={<PackageX />} label="خامات ناقصة" value={s.missingMaterials} tone={s.missingMaterials > 0 ? "danger" : "muted"} />
        <StatCard icon={<Package />} label="مراحل إنتاج متوقفة" value={s.stoppedStages} tone={s.stoppedStages > 0 ? "danger" : "muted"} />
        <StatCard icon={<PackageCheck />} label="جاهزة للتسليم" value={s.readyForDelivery} tone={s.readyForDelivery > 0 ? "done" : "muted"} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-5 xl:grid-cols-5">
        {/* يحتاج انتباهك */}
        <section className="surface xl:col-span-3">
          <h2 className="border-b border-border/70 px-4 py-3 text-[15px] font-bold">
            يحتاج انتباهك الآن
          </h2>
          {attention.length === 0 ? (
            <p className="px-4 py-8 text-center text-[14px] text-muted-foreground">
              كل الطلبيات تحت السيطرة — لا توجد تنبيهات حاليًا.
            </p>
          ) : (
            <ul className="divide-y divide-border/60 px-2 py-1">
              {attention.map((a) => (
                <li key={a.key}>
                  <button
                    type="button"
                    onClick={() => a.orderId && onOpenOrder(a.orderId)}
                    className="flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-start outline-none transition-colors hover:bg-accent/60 focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <span
                      className={
                        a.tone === "danger"
                          ? "size-2 shrink-0 rounded-full bg-destructive"
                          : "size-2 shrink-0 rounded-full bg-warning"
                      }
                      aria-hidden
                    />
                    <span className="text-[14px] leading-6">{a.text}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* إنتاجية المنتجات */}
        <section className="surface px-4 py-4 xl:col-span-2">
          <h2 className="mb-1 text-[15px] font-bold">القطع المطلوبة حسب المنتج</h2>
          <p className="mb-3 text-[12.5px] text-muted-foreground">
            إجمالي الكميات في الطلبيات غير الملغاة
          </p>
          <div className="h-[220px]" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 4, right: 4, left: -18, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border) / 0.6)" vertical={false} />
                <XAxis
                  dataKey="product"
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickFormatter={(v: string) => v.replace("ال", "")}
                />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip
                  cursor={{ fill: "hsl(var(--accent) / 0.4)" }}
                  contentStyle={{
                    direction: "rtl",
                    borderRadius: 10,
                    border: "1px solid hsl(var(--border))",
                    background: "hsl(var(--popover))",
                    fontSize: 13,
                  }}
                  formatter={(value) => [`${value} قطعة`, "الكمية"]}
                />
                <Bar dataKey="pieces" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={54} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="num mt-2 text-[12.5px] text-muted-foreground" dir="ltr">
            إجمالي {s.totalPieces} قطعة في {s.totalOrders} طلبيات
          </p>
        </section>
      </div>

      {/* ملخص سريع للطلبيات النشطة */}
      <section className="surface mt-5 overflow-hidden">
        <h2 className="border-b border-border/70 px-4 py-3 text-[15px] font-bold">
          الطلبيات النشطة
        </h2>
        <div className="overflow-x-auto">
          <table className="ruled-table min-w-[640px]">
            <thead>
              <tr>
                <th>رقم الطلب</th>
                <th>العميل</th>
                <th>المنتج</th>
                <th>الكمية</th>
                <th>التسليم</th>
                <th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {data.orders.filter(isActiveOrder).map((o) => {
                const a = deadlineInfo(o);
                return (
                  <tr key={o.id} data-clickable onClick={() => onOpenOrder(o.id)}>
                    <td className="num font-bold" dir="ltr">
                      {o.id}
                    </td>
                    <td>{o.client}</td>
                    <td>{o.product}</td>
                    <td className="num">{o.quantity}</td>
                    <td>
                      <ToneText tone={a.tone}>
                        {a.days === null ? a.label : a.days < 0 ? `متأخرة ${Math.abs(a.days)} يوم` : `${a.days} يوم`}
                      </ToneText>
                    </td>
                    <td>
                      <StatusBadge label={o.status} tone={a.tone === "muted" ? "muted" : a.tone} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
