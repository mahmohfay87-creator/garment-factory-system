import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type {
  AppData,
  DailyNote,
  MaterialItem,
  Order,
  ProductionStage,
} from "@/lib/domain";
import { SEED_DATA } from "@/data/seed";

const STORAGE_KEY = "garment-factory-v1";

function loadData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AppData;
      if (parsed && Array.isArray(parsed.orders)) return parsed;
    }
  } catch {
    // بيانات تالفة — نبدأ من جديد
  }
  return SEED_DATA;
}

interface StoreContextValue {
  data: AppData;
  orders: Order[];
  stages: ProductionStage[];
  materials: MaterialItem[];
  dailyNotes: DailyNote[];
  saveOrder: (order: Order) => void;
  deleteOrder: (id: string) => void;
  nextOrderId: () => string;
  saveStage: (stage: ProductionStage) => void;
  deleteStage: (id: string) => void;
  nextStageId: () => string;
  saveMaterial: (m: MaterialItem) => void;
  deleteMaterial: (id: string) => void;
  nextMaterialId: () => string;
  saveDailyNote: (orderId: string, date: string, note: string) => void;
  resetAll: () => void;
  replaceAll: (data: AppData) => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(loadData);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // مساحة ممتلئة — نتجاهل بصمت
    }
  }, [data]);

  const nextOrderId = useCallback(() => {
    const seq = data.orderSeq + 1;
    return `ORD-${String(seq).padStart(3, "0")}`;
  }, [data.orderSeq]);

  const nextStageId = useCallback(() => {
    const seq = data.stageSeq + 1;
    return `STG-${String(seq).padStart(3, "0")}`;
  }, [data.stageSeq]);

  const nextMaterialId = useCallback(() => {
    const seq = data.materialSeq + 1;
    return `MAT-${String(seq).padStart(3, "0")}`;
  }, [data.materialSeq]);

  const saveOrder = useCallback((order: Order) => {
    setData((prev) => {
      const exists = prev.orders.some((o) => o.id === order.id);
      return {
        ...prev,
        orders: exists
          ? prev.orders.map((o) => (o.id === order.id ? order : o))
          : [...prev.orders, order],
        orderSeq: exists ? prev.orderSeq : prev.orderSeq + 1,
      };
    });
  }, []);

  const deleteOrder = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      orders: prev.orders.filter((o) => o.id !== id),
      stages: prev.stages.filter((s) => s.orderId !== id),
      materials: prev.materials.filter((m) => m.orderId !== id),
      dailyNotes: prev.dailyNotes.filter((n) => n.orderId !== id),
    }));
  }, []);

  const saveStage = useCallback((stage: ProductionStage) => {
    setData((prev) => {
      const exists = prev.stages.some((s) => s.id === stage.id);
      return {
        ...prev,
        stages: exists
          ? prev.stages.map((s) => (s.id === stage.id ? stage : s))
          : [...prev.stages, stage],
        stageSeq: exists ? prev.stageSeq : prev.stageSeq + 1,
      };
    });
  }, []);

  const deleteStage = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      stages: prev.stages.filter((s) => s.id !== id),
    }));
  }, []);

  const saveMaterial = useCallback((m: MaterialItem) => {
    setData((prev) => {
      const exists = prev.materials.some((x) => x.id === m.id);
      return {
        ...prev,
        materials: exists
          ? prev.materials.map((x) => (x.id === m.id ? m : x))
          : [...prev.materials, m],
        materialSeq: exists ? prev.materialSeq : prev.materialSeq + 1,
      };
    });
  }, []);

  const deleteMaterial = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      materials: prev.materials.filter((m) => m.id !== id),
    }));
  }, []);

  const saveDailyNote = useCallback((orderId: string, date: string, note: string) => {
    setData((prev) => {
      const rest = prev.dailyNotes.filter(
        (n) => !(n.orderId === orderId && n.date === date),
      );
      return {
        ...prev,
        dailyNotes: note.trim() ? [...rest, { orderId, date, note }] : rest,
      };
    });
  }, []);

  const resetAll = useCallback(() => setData(SEED_DATA), []);

  const replaceAll = useCallback((d: AppData) => setData(d), []);

  const value = useMemo<StoreContextValue>(
    () => ({
      data,
      orders: data.orders,
      stages: data.stages,
      materials: data.materials,
      dailyNotes: data.dailyNotes,
      saveOrder,
      deleteOrder,
      nextOrderId,
      saveStage,
      deleteStage,
      nextStageId,
      saveMaterial,
      deleteMaterial,
      nextMaterialId,
      saveDailyNote,
      resetAll,
      replaceAll,
    }),
    [
      data,
      saveOrder,
      deleteOrder,
      nextOrderId,
      saveStage,
      deleteStage,
      nextStageId,
      saveMaterial,
      deleteMaterial,
      nextMaterialId,
      saveDailyNote,
      resetAll,
      replaceAll,
    ],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
