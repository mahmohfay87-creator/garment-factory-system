import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { Tone } from "@/lib/domain";

// شارة الحالة بلون من سلّم لوحة الألوان
export function StatusBadge({
  label,
  tone = "muted",
  className,
}: {
  label: string;
  tone?: Tone;
  className?: string;
}) {
  const tones: Record<Tone, string> = {
    danger: "bg-destructive/12 text-destructive border-destructive/35",
    warn: "bg-warning/14 text-warning border-warning/40",
    ok: "bg-primary/10 text-primary border-primary/30",
    done: "bg-success/12 text-success border-success/35",
    muted: "bg-muted/70 text-muted-foreground border-border",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-[13px] font-medium leading-6",
        tones[tone],
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-current" aria-hidden />
      {label}
    </span>
  );
}

export function ToneText({ children, tone }: { children: ReactNode; tone: Tone }) {
  const map: Record<Tone, string> = {
    danger: "text-destructive",
    warn: "text-warning",
    ok: "text-primary",
    done: "text-success",
    muted: "text-muted-foreground",
  };
  return <span className={cn("num font-semibold", map[tone])}>{children}</span>;
}

export function StatCard({
  icon,
  label,
  value,
  tone = "muted",
  hint,
}: {
  icon: ReactNode;
  label: string;
  value: ReactNode;
  tone?: Tone;
  hint?: string;
}) {
  const ring: Record<Tone, string> = {
    danger: "text-destructive",
    warn: "text-warning",
    ok: "text-primary",
    done: "text-success",
    muted: "text-muted-foreground",
  };
  return (
    <div className="surface flex items-start gap-3 px-4 py-4">
      <div className={cn("mt-0.5 shrink-0 [&_svg]:size-5", ring[tone])} aria-hidden>
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-[13px] font-medium text-muted-foreground">{label}</div>
        <div className="num text-[28px] font-bold leading-9 tracking-tight text-foreground">
          {value}
        </div>
        {hint ? <div className="text-[12.5px] text-muted-foreground">{hint}</div> : null}
      </div>
    </div>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-1 px-6 py-14 text-center">
      <p className="text-[15px] font-medium text-muted-foreground">{title}</p>
      {hint ? <p className="text-[13px] text-muted-foreground/80">{hint}</p> : null}
    </div>
  );
}

// حقول النماذج
export function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("flex flex-col gap-1.5", className)}>
      <span className="text-[13px] font-bold text-foreground/85">{label}</span>
      {children}
    </label>
  );
}

const inputCls =
  "h-10 w-full rounded-lg border border-input bg-popover/80 px-3 text-[15px] text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-primary/25 disabled:opacity-60";

export function TextInput({
  value,
  onChange,
  placeholder,
  type = "text",
  required,
  dir,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
  dir?: "ltr" | "rtl";
}) {
  return (
    <input
      type={type}
      value={value}
      required={required}
      placeholder={placeholder}
      dir={dir}
      onChange={(e) => onChange(e.target.value)}
      className={cn(inputCls, "num")}
    />
  );
}

export function NumberInput({
  value,
  onChange,
  min = 0,
}: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
}) {
  return (
    <input
      type="number"
      value={Number.isFinite(value) ? value : ""}
      min={min}
      dir="ltr"
      onChange={(e) => onChange(Number(e.target.value))}
      className={cn(inputCls, "num text-left")}
    />
  );
}

export function DateInput({
  value,
  onChange,
  required,
}: {
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <input
      type="date"
      value={value}
      required={required}
      dir="ltr"
      onChange={(e) => onChange(e.target.value)}
      className={cn(inputCls, "num text-left")}
    />
  );
}

export function SelectInput({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: readonly string[];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={cn(inputCls, "cursor-pointer appearance-none bg-popover/80")}
    >
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export function TextArea({
  value,
  onChange,
  placeholder,
  rows = 3,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  rows?: number;
}) {
  return (
    <textarea
      value={value}
      rows={rows}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      className={cn(inputCls, "h-auto min-h-[80px] py-2 leading-6")}
    />
  );
}

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-[26px] font-extrabold leading-8 tracking-tight">{title}</h1>
        {subtitle ? (
          <p className="mt-1 text-[14px] text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      {actions ? <div className="flex items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function ProgressBar({ pct, tone = "ok" }: { pct: number; tone?: Tone }) {
  const fill: Record<Tone, string> = {
    danger: "bg-destructive",
    warn: "bg-warning",
    ok: "bg-primary",
    done: "bg-success",
    muted: "bg-muted-foreground/50",
  };
  return (
    <div className="h-1.5 w-full min-w-[70px] overflow-hidden rounded-full bg-muted/80">
      <div
        className={cn("h-full rounded-full transition-[width] duration-300", fill[tone])}
        style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
      />
    </div>
  );
}
