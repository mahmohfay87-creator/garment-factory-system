import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  deadlineInfo,
  formatDate,
  materialInfo,
  stageProgress,
  STAGE_STATUSES,
  type MaterialItem,
  type Order,
  type ProductionStage,
  type StageStatus,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import {
  MaterialFormSheet,
  OrderFormSheet,
  StageFormSheet,
} from "@/components/forms";
import { ProgressBar, StatusBadge } from "@/components/ui-bits";

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2">
      <span className="shrink-0 text-[13.5px] font-medium text-muted-foreground">{label}</span>
      <span className="text-end text-[14.5px] font-semibold">{value}</span>
    </div>
  );
}

function stageTone(s: StageStatus) {
  if (s === "متوقفة") return "danger" as const;
  if (s === "جارية") return "ok" as const;
  if (s === "مكتملة") return "done" as const;
  return "muted" as const;
}

export function OrderDetailSheet({
  order,
  onOpenChange,
}: {
  order: Order | null;
  onOpenChange: (v: boolean) => void;
}) {
  const { stages, materials, deleteOrder, saveStage } = useStore();
  const [editOpen, setEditOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [stageForm, setStageForm] = useState<{ open: boolean; editing: ProductionStage | null }>({
    open: false,
    editing: null,
  });
  const [matForm, setMatForm] = useState<{ open: boolean; editing: MaterialItem | null }>({
    open: false,
    editing: null,
  });

  if (!order) return null;

  const orderStages = stages
    .filter((s) => s.orderId === order.id)
    .sort((a, b) => a.startDate.localeCompare(b.startDate));
  const orderMaterials = materials.filter((m) => m.orderId === order.id);
  const progress = stageProgress(order.id, stages);
  const alert = deadlineInfo(order);

  const cycleStage = (s: ProductionStage) => {
    const idx = STAGE_STATUSES.indexOf(s.status);
    const next = STAGE_STATUSES[(idx + 1) % STAGE_STATUSES.length];
    saveStage({ ...s, status: next });
    toast.success(`مرحلة «${s.stage}» أصبحت: ${next}`);
  };

  return (
    <>
      <Sheet open={!!order} onOpenChange={onOpenChange}>
        <SheetContent side="left" className="w-full overflow-y-auto sm:max-w-2xl">
          <SheetHeader className="mb-2">
            <div className="flex items-center justify-between gap-2">
              <SheetTitle className="num text-xl" dir="ltr">
                {order.id}
              </SheetTitle>
              <div className="flex items-center gap-1.5">
                <Button variant="outline" size="sm" onClick={() => setEditOpen(true)}>
                  <Pencil className="me-1 size-3.5" />
                  تعديل
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => setConfirmDelete(true)}
                >
                  <Trash2 className="me-1 size-3.5" />
                  حذف
                </Button>
              </div>
            </div>
            <SheetDescription>
              {order.client} — {order.product}
            </SheetDescription>
          </SheetHeader>

          <div className="surface mb-5 px-4 py-1">
            <InfoRow label="نوع العميل" value={order.clientType} />
            <Separator />
            <InfoRow label="تاريخ الطلب" value={<span className="num">{formatDate(order.date)}</span>} />
            <Separator />
            <InfoRow
              label="الكمية"
              value={
                <span className="num">
                  {order.quantity} قطعة
                </span>
              }
            />
            <Separator />
            <InfoRow label="المقاسات / المواصفات" value={order.specs || "—"} />
            <Separator />
            <InfoRow
              label="تاريخ التسليم المطلوب"
              value={<span className="num">{formatDate(order.deliveryDate)}</span>}
            />
            <Separator />
            <InfoRow label="درجة الأولوية" value={<StatusBadge label={order.priority} tone={order.priority === "عالية" ? "danger" : order.priority === "متوسطة" ? "warn" : "muted"} />} />
            <Separator />
            <InfoRow label="حالة الطلب" value={<StatusBadge label={order.status} tone={alert.tone === "muted" ? "muted" : alert.tone} />} />
            <Separator />
            <InfoRow label="تنبيه الموعد" value={<StatusBadge label={alert.label} tone={alert.tone} />} />
            {order.notes ? (
              <>
                <Separator />
                <InfoRow label="ملاحظات" value={order.notes} />
              </>
            ) : null}
          </div>

          {/* مراحل الإنتاج */}
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-[15px] font-bold">
              مراحل الإنتاج{" "}
              <span className="num text-muted-foreground">
                {progress.done}/{progress.total}
              </span>
            </h3>
            <Button variant="outline" size="sm" onClick={() => setStageForm({ open: true, editing: null })}>
              <Plus className="me-1 size-3.5" />
              إضافة مرحلة
            </Button>
          </div>
          <div className="mb-1 px-0.5">
            <ProgressBar pct={progress.pct} tone={progress.pct === 100 ? "done" : "ok"} />
          </div>
          <div className="mb-6">
            {orderStages.length === 0 ? (
              <p className="py-3 text-[13.5px] text-muted-foreground">
                لا توجد مراحل مسجلة لهذه الطلبية بعد.
              </p>
            ) : (
              <ul className="divide-y divide-border/70">
                {orderStages.map((s) => (
                  <li key={s.id} className="flex flex-wrap items-center gap-2 py-2.5">
                    <button
                      type="button"
                      title="اضغط لتغيير الحالة"
                      onClick={() => cycleStage(s)}
                      className="cursor-pointer rounded-full outline-none transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <StatusBadge label={`${s.stage} — ${s.status}`} tone={stageTone(s.status)} />
                    </button>
                    <span className="num text-[12.5px] text-muted-foreground" dir="ltr">
                      {formatDate(s.startDate)} ← {formatDate(s.endDate)}
                    </span>
                    <span className="text-[12.5px] text-muted-foreground">• {s.responsible}</span>
                    <span className="ms-auto flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 px-2 text-[12.5px]"
                        onClick={() => setStageForm({ open: true, editing: s })}
                      >
                        تعديل
                      </Button>
                    </span>
                    {s.notes ? (
                      <span className="w-full text-[12.5px] text-muted-foreground">{s.notes}</span>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* الخامات */}
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-[15px] font-bold">الخامات والإكسسوارات</h3>
            <Button variant="outline" size="sm" onClick={() => setMatForm({ open: true, editing: null })}>
              <Plus className="me-1 size-3.5" />
              إضافة خامة
            </Button>
          </div>
          <div>
            {orderMaterials.length === 0 ? (
              <p className="py-3 text-[13.5px] text-muted-foreground">
                لا توجد خامات مسجلة لهذه الطلبية بعد.
              </p>
            ) : (
              <ul className="divide-y divide-border/70">
                {orderMaterials.map((m) => {
                  const info = materialInfo(m);
                  return (
                    <li key={m.id} className="flex flex-wrap items-center gap-2 py-2.5">
                      <span className="text-[14px] font-semibold">
                        {m.name}{" "}
                        <span className="num font-normal text-muted-foreground">
                          ({m.kind} — {m.quantity} {m.unit})
                        </span>
                      </span>
                      <StatusBadge label={info.label} tone={info.tone} />
                      <span className="text-[12.5px] text-muted-foreground">المورد: {m.supplier || "—"}</span>
                      <span className="ms-auto">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-[12.5px]"
                          onClick={() => setMatForm({ open: true, editing: m })}
                        >
                          تعديل
                        </Button>
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </SheetContent>
      </Sheet>

      <OrderFormSheet open={editOpen} onOpenChange={setEditOpen} editing={order} />
      <StageFormSheet
        open={stageForm.open}
        onOpenChange={(v) => setStageForm((s) => ({ ...s, open: v }))}
        editing={stageForm.editing}
        presetOrderId={order.id}
      />
      <MaterialFormSheet
        open={matForm.open}
        onOpenChange={(v) => setMatForm((s) => ({ ...s, open: v }))}
        editing={matForm.editing}
        presetOrderId={order.id}
      />

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الطلبية {order.id}؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف الطلبية مع جميع مراحلها وخاماتها وملاحظاتها — لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                deleteOrder(order.id);
                toast.success(`تم حذف الطلبية ${order.id}`);
                setConfirmDelete(false);
                onOpenChange(false);
              }}
            >
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
