import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { toast } from "sonner";
import {
  CLIENT_TYPES,
  MATERIAL_STATUSES,
  ORDER_STATUSES,
  PRIORITIES,
  PRODUCTS,
  STAGE_PIPELINE,
  STAGE_STATUSES,
  UNITS,
  todayISO,
  type MaterialItem,
  type MaterialKind,
  type Order,
  type Priority,
  type ProductionStage,
} from "@/lib/domain";
import { useStore } from "@/store/store";
import {
  DateInput,
  Field,
  NumberInput,
  SelectInput,
  TextArea,
  TextInput,
} from "@/components/ui-bits";

const grid = "grid grid-cols-1 gap-4 sm:grid-cols-2";

// ---------- نموذج الطلبية ----------
export function OrderFormSheet({
  open,
  onOpenChange,
  editing,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: Order | null;
}) {
  const { saveOrder, nextOrderId } = useStore();
  const empty: Order = {
    id: nextOrderId(),
    date: todayISO(),
    client: "",
    clientType: "جملة",
    product: PRODUCTS[0],
    quantity: 1,
    specs: "",
    deliveryDate: todayISO(),
    priority: "متوسطة",
    status: "جديدة",
    notes: "",
  };
  const [form, setForm] = useState<Order>(empty);

  useEffect(() => {
    if (open) setForm(editing ? { ...editing } : empty);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  const set = <K extends keyof Order>(k: K, v: Order[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.client.trim()) {
      toast.error("اكتب اسم العميل أولًا");
      return;
    }
    if (!form.quantity || form.quantity <= 0) {
      toast.error("اكتب كمية صحيحة");
      return;
    }
    saveOrder(form);
    toast.success(editing ? `تم تعديل الطلبية ${form.id}` : `تم تسجيل الطلبية ${form.id}`);
    onOpenChange(false);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-full overflow-y-auto sm:max-w-xl">
        <SheetHeader className="mb-4">
          <SheetTitle>{editing ? `تعديل الطلبية ${editing.id}` : "تسجيل طلبية جديدة"}</SheetTitle>
          <SheetDescription>
            {editing
              ? "عدّل بيانات الطلبية ثم اضغط حفظ."
              : "سجّل بيانات الطلبية الجديدة — سيُنشأ رقم تلقائي لها."}
          </SheetDescription>
        </SheetHeader>
        <form onSubmit={submit} className="flex flex-col gap-4">
          <div className={grid}>
            <Field label="رقم الطلب">
              <TextInput value={form.id} onChange={() => undefined} dir="ltr" />
            </Field>
            <Field label="تاريخ الطلب">
              <DateInput value={form.date} onChange={(v) => set("date", v)} required />
            </Field>
          </div>
          <Field label="اسم العميل">
            <TextInput
              value={form.client}
              onChange={(v) => set("client", v)}
              placeholder="مثال: مؤسسة النور للزي الموحد"
              required
            />
          </Field>
          <div className={grid}>
            <Field label="نوع العميل">
              <SelectInput
                value={form.clientType}
                onChange={(v) => set("clientType", v as Order["clientType"])}
                options={CLIENT_TYPES}
              />
            </Field>
            <Field label="المنتج">
              <SelectInput
                value={form.product}
                onChange={(v) => set("product", v)}
                options={PRODUCTS}
              />
            </Field>
          </div>
          <div className={grid}>
            <Field label="الكمية">
              <NumberInput value={form.quantity} onChange={(v) => set("quantity", v || 0)} />
            </Field>
            <Field label="تاريخ التسليم المطلوب">
              <DateInput
                value={form.deliveryDate}
                onChange={(v) => set("deliveryDate", v)}
                required
              />
            </Field>
          </div>
          <Field label="المقاسات / المواصفات">
            <TextInput
              value={form.specs}
              onChange={(v) => set("specs", v)}
              placeholder="مثال: مقاسات S - XXL / أسود - كحلي"
            />
          </Field>
          <div className={grid}>
            <Field label="درجة الأولوية">
              <SelectInput
                value={form.priority}
                onChange={(v) => set("priority", v as Priority)}
                options={PRIORITIES}
              />
            </Field>
            <Field label="حالة الطلب">
              <SelectInput
                value={form.status}
                onChange={(v) => set("status", v as Order["status"])}
                options={ORDER_STATUSES}
              />
            </Field>
          </div>
          <Field label="ملاحظات">
            <TextArea
              value={form.notes}
              onChange={(v) => set("notes", v)}
              placeholder="أي تفاصيل إضافية عن الطلبية"
            />
          </Field>
          <div className="mt-2 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              إلغاء
            </Button>
            <Button type="submit">حفظ الطلبية</Button>
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}

// ---------- نموذج مرحلة إنتاج ----------
export function StageFormSheet({
  open,
  onOpenChange,
  editing,
  presetOrderId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: ProductionStage | null;
  presetOrderId?: string;
}) {
  const { orders, saveStage, nextStageId } = useStore();
  const empty: ProductionStage = {
    id: nextStageId(),
    orderId: presetOrderId ?? (orders[0]?.id ?? ""),
    stage: STAGE_PIPELINE[0],
    startDate: todayISO(),
    endDate: todayISO(),
    status: "لم تبدأ",
    responsible: "",
    notes: "",
  };
  const [form, setForm] = useState<ProductionStage>(empty);

  useEffect(() => {
    if (open) setForm(editing ? { ...editing } : empty);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing, presetOrderId]);

  const set = <K extends keyof ProductionStage>(k: K, v: ProductionStage[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.orderId) {
      toast.error("اختر الطلبية أولًا");
      return;
    }
    if (!form.responsible.trim()) {
      toast.error("اكتب اسم القسم أو المسؤول");
      return;
    }
    saveStage(form);
    toast.success(editing ? "تم تعديل المرحلة" : "تمت إضافة المرحلة");
    onOpenChange(false);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-full overflow-y-auto sm:max-w-xl">
        <SheetHeader className="mb-4">
          <SheetTitle>{editing ? "تعديل مرحلة إنتاج" : "إضافة مرحلة إنتاج"}</SheetTitle>
          <SheetDescription>اربط المرحلة بطلبية وحدّد مواعيدها وحالتها والمسؤول عنها.</SheetDescription>
        </SheetHeader>
        <form onSubmit={submit} className="flex flex-col gap-4">
          <div className={grid}>
            <Field label="الطلبية">
              <SelectInput
                value={form.orderId}
                onChange={(v) => set("orderId", v)}
                options={orders.map((o) => o.id)}
              />
            </Field>
            <Field label="المرحلة">
              <SelectInput
                value={form.stage}
                onChange={(v) => set("stage", v)}
                options={STAGE_PIPELINE}
              />
            </Field>
          </div>
          <div className={grid}>
            <Field label="تاريخ البدء">
              <DateInput value={form.startDate} onChange={(v) => set("startDate", v)} required />
            </Field>
            <Field label="تاريخ الانتهاء المتوقع">
              <DateInput value={form.endDate} onChange={(v) => set("endDate", v)} required />
            </Field>
          </div>
          <div className={grid}>
            <Field label="حالة المرحلة">
              <SelectInput
                value={form.status}
                onChange={(v) => set("status", v as ProductionStage["status"])}
                options={STAGE_STATUSES}
              />
            </Field>
            <Field label="المسؤول">
              <TextInput
                value={form.responsible}
                onChange={(v) => set("responsible", v)}
                placeholder="مثال: قسم الخياطة"
                required
              />
            </Field>
          </div>
          <Field label="ملاحظات">
            <TextArea
              value={form.notes}
              onChange={(v) => set("notes", v)}
              placeholder="مثال: تم إنجاز 60%"
            />
          </Field>
          <div className="mt-2 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              إلغاء
            </Button>
            <Button type="submit">حفظ المرحلة</Button>
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}

// ---------- نموذج خامة / إكسسوار ----------
export function MaterialFormSheet({
  open,
  onOpenChange,
  editing,
  presetOrderId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: MaterialItem | null;
  presetOrderId?: string;
}) {
  const { orders, saveMaterial, nextMaterialId } = useStore();
  const empty: MaterialItem = {
    id: nextMaterialId(),
    orderId: presetOrderId ?? (orders[0]?.id ?? ""),
    kind: "خامة",
    name: "",
    quantity: 1,
    unit: UNITS[0],
    supplier: "",
    expectedDate: todayISO(),
    status: "لم يتم الطلب",
    notes: "",
  };
  const [form, setForm] = useState<MaterialItem>(empty);

  useEffect(() => {
    if (open) setForm(editing ? { ...editing } : empty);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing, presetOrderId]);

  const set = <K extends keyof MaterialItem>(k: K, v: MaterialItem[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.orderId) {
      toast.error("اختر الطلبية أولًا");
      return;
    }
    if (!form.name.trim()) {
      toast.error("اكتب اسم الخامة أو الإكسسوار");
      return;
    }
    saveMaterial(form);
    toast.success(editing ? "تم تعديل الخامة" : "تمت إضافة الخامة");
    onOpenChange(false);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-full overflow-y-auto sm:max-w-xl">
        <SheetHeader className="mb-4">
          <SheetTitle>
            {editing ? "تعديل خامة / إكسسوار" : "إضافة خامة / إكسسوار"}
          </SheetTitle>
          <SheetDescription>تابع حالة طلب الخامات من المورد وموعد استلامها المتوقع.</SheetDescription>
        </SheetHeader>
        <form onSubmit={submit} className="flex flex-col gap-4">
          <div className={grid}>
            <Field label="الطلبية">
              <SelectInput
                value={form.orderId}
                onChange={(v) => set("orderId", v)}
                options={orders.map((o) => o.id)}
              />
            </Field>
            <Field label="النوع">
              <SelectInput
                value={form.kind}
                onChange={(v) => set("kind", v as MaterialKind)}
                options={["خامة", "إكسسوار"]}
              />
            </Field>
          </div>
          <Field label="اسم الخامة / الإكسسوار">
            <TextInput
              value={form.name}
              onChange={(v) => set("name", v)}
              placeholder="مثال: قماش أزهري (قطيفة)"
              required
            />
          </Field>
          <div className={`${grid} grid-cols-2`}>
            <Field label="الكمية">
              <NumberInput value={form.quantity} onChange={(v) => set("quantity", v || 0)} />
            </Field>
            <Field label="الوحدة">
              <SelectInput value={form.unit} onChange={(v) => set("unit", v)} options={UNITS} />
            </Field>
          </div>
          <div className={grid}>
            <Field label="المورد">
              <TextInput
                value={form.supplier}
                onChange={(v) => set("supplier", v)}
                placeholder="مثال: النور للأقمشة"
              />
            </Field>
            <Field label="تاريخ الاستلام المتوقع">
              <DateInput value={form.expectedDate} onChange={(v) => set("expectedDate", v)} required />
            </Field>
          </div>
          <Field label="حالة الاستلام">
            <SelectInput
              value={form.status}
              onChange={(v) => set("status", v as MaterialItem["status"])}
              options={MATERIAL_STATUSES}
            />
          </Field>
          <Field label="ملاحظات">
            <TextArea value={form.notes} onChange={(v) => set("notes", v)} />
          </Field>
          <div className="mt-2 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              إلغاء
            </Button>
            <Button type="submit">حفظ</Button>
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}
