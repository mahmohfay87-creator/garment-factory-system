import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Factory, LockKeyhole, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { readSession, saveSession, signIn, verifySession, type AuthSession } from '@/lib/supabase-auth';

export function AuthGate({ children }: { children: (session: AuthSession, logout: () => void) => ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(readSession);
  const [checking, setChecking] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    const current = readSession();
    if (!current) { setChecking(false); return; }
    verifySession(current).then(valid => {
      if (!active) return;
      if (!valid) { saveSession(null); setSession(null); }
      setChecking(false);
    });
    return () => { active = false; };
  }, []);

  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError(''); setBusy(true);
    try { const next = await signIn(email.trim(), password); setSession(next); }
    catch (e) { setError(e instanceof Error ? e.message : 'حدث خطأ أثناء تسجيل الدخول.'); }
    finally { setBusy(false); }
  };
  const logout = () => { saveSession(null); setSession(null); setPassword(''); };

  if (checking) return <div className="flex min-h-screen items-center justify-center text-muted-foreground">جارٍ التحقق من تسجيل الدخول...</div>;
  if (session) return <>{children(session, logout)}</>;

  return <main dir="rtl" className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
    <form onSubmit={submit} className="w-full max-w-md space-y-5 rounded-2xl border bg-card p-7 shadow-sm">
      <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Factory className="size-7" /></div>
      <div className="text-center"><h1 className="text-2xl font-extrabold">نظام إدارة مصنع الملابس</h1><p className="mt-2 text-sm text-muted-foreground">سجّلي الدخول بالبريد الإلكتروني وكلمة المرور</p></div>
      <label className="block space-y-2 text-sm font-semibold">البريد الإلكتروني<div className="relative"><Mail className="absolute right-3 top-3 size-4 text-muted-foreground"/><Input className="pr-10" type="email" autoComplete="username" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com" dir="ltr"/></div></label>
      <label className="block space-y-2 text-sm font-semibold">كلمة المرور<div className="relative"><LockKeyhole className="absolute right-3 top-3 size-4 text-muted-foreground"/><Input className="pr-10" type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="كلمة المرور"/></div></label>
      {error && <p role="alert" className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
      <Button className="w-full" type="submit" disabled={busy}>{busy ? 'جارٍ تسجيل الدخول...' : 'دخول'}</Button>
      <p className="text-center text-xs text-muted-foreground">الدخول متاح للمستخدمين المسجلين في النظام فقط</p>
    </form>
  </main>;
}
