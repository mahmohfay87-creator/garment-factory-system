const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
const SESSION_KEY = 'garment-factory-auth-v1';

export type AuthSession = { access_token: string; refresh_token: string; user: { id: string; email?: string } };

function config() {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) throw new Error('إعدادات Supabase غير مكتملة.');
  return { url: SUPABASE_URL.replace(/\/$/, ''), key: SUPABASE_ANON_KEY };
}

export function readSession(): AuthSession | null {
  try {
    const value = localStorage.getItem(SESSION_KEY);
    return value ? JSON.parse(value) as AuthSession : null;
  } catch { return null; }
}

export function saveSession(session: AuthSession | null) {
  if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  else localStorage.removeItem(SESSION_KEY);
}

export async function signIn(email: string, password: string): Promise<AuthSession> {
  const { url, key } = config();
  const response = await fetch(`${url}/auth/v1/token?grant_type=password`, {
    method: 'POST', headers: { apikey: key, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.msg || result.message || result.error_description || 'تعذر تسجيل الدخول. راجعي البريد وكلمة المرور.');
  const session = result as AuthSession;
  saveSession(session);
  return session;
}

export async function verifySession(session: AuthSession): Promise<boolean> {
  try {
    const { url, key } = config();
    const response = await fetch(`${url}/auth/v1/user`, { headers: { apikey: key, Authorization: `Bearer ${session.access_token}` } });
    return response.ok;
  } catch { return false; }
}
