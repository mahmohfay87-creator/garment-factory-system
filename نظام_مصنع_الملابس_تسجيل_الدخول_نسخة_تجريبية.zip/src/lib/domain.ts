// الأنواع الأساسية ودوال الحساب المشتقة — مطابقة لمنطق ملف الإكسل

export type ClientType = "جملة" | "قطاعي";
export type Priority = "عالية" | "متوسطة" | "منخفضة";
export type OrderStatus =
  | "جديدة"
  | "قيد التجهيز"
  | "قيد الإنتاج"
  | "جاهزة للتسليم"
  | "مكتملة"
  | "ملغاة";

export type StageStatus = "لم تبدأ" | "جارية" | "مكتملة" | "متوقفة";
export type MaterialStatus = "لم يتم الطلب" | "تم الطلب" | "تم الاستلام" | "ناقص";
export type MaterialKind = "خامة" | "إكسسوار";

export interface Order {
  id: string; // ORD-001
  date: string; // YYYY-MM-DD
  client: string;
  clientType: ClientType;
  product: string;
  quantity: number;
  specs: string;
  deliveryDate: string; // YYYY-MM-DD
  priority: Priority;
  status: OrderStatus;
  notes: string;
}

export interface ProductionStage {
  id: string;
  orderId: string;
  stage: string;
  startDate: string;
  endDate: string;
  status: StageStatus;
  responsible: string;
  notes: string;
}

export interface MaterialItem {
  id: string;
  orderId: string;
  kind: MaterialKind;
  name: string;
  quantity: number;
  unit: string;
  supplier: string;
  expectedDate: string;
  status: MaterialStatus;
  notes: string;
}

export interface DailyNote {
  orderId: string;
  date: string; // YYYY-MM-DD
  note: string;
}

export interface AppData {
  orders: Order[];
  stages: ProductionStage[];
  materials: MaterialItem[];
  dailyNotes: DailyNote[];
  orderSeq: number;
  stageSeq: number;
  materialSeq: number;
}

// ---------- الثوابت ----------
export const STAGE_PIPELINE = [
  "استلام الخامات",
  "القص",
  "الخياطة",
  "الكي والتشطيب",
  "الفحص والجودة",
  "التغليف",
] as const;

export const CLIENT_TYPES: ClientType[] = ["جملة", "قطاعي"];
export const PRODUCTS = ["الزي الأزهري", "الجلباب الرجالي", "البدلة الرجالية"];
export const PRIORITIES: Priority[] = ["عالية", "متوسطة", "منخفضة"];
export const ORDER_STATUSES: OrderStatus[] = [
  "جديدة",
  "قيد التجهيز",
  "قيد الإنتاج",
  "جاهزة للتسليم",
  "مكتملة",
  "ملغاة",
];
export const STAGE_STATUSES: StageStatus[] = ["لم تبدأ", "جارية", "مكتملة", "متوقفة"];
export const MATERIAL_STATUSES: MaterialStatus[] = [
  "لم يتم الطلب",
  "تم الطلب",
  "تم الاستلام",
  "ناقص",
];
export const UNITS = ["متر", "قطعة", "كجم", "لفة", "عبوة", "طقم"];

// ---------- التواريخ ----------
export function todayISO(): string {
  const d = new Date();
  return toISODate(d);
}

export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function daysUntil(iso: string, from: Date = new Date()): number {
  const target = new Date(iso + "T00:00:00");
  const base = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  return Math.round((target.getTime() - base.getTime()) / 86400000);
}

export function formatDate(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(d);
}

export function formatLongDate(d: Date = new Date()): string {
  return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(d);
}

// ---------- التنبيهات ----------
export type Tone = "danger" | "warn" | "ok" | "done" | "muted";

export interface AlertInfo {
  days: number | null;
  label: string;
  tone: Tone;
}

export function deadlineInfo(order: Order): AlertInfo {
  if (order.status === "ملغاة") return { days: null, label: "ملغاة", tone: "muted" };
  if (order.status === "مكتملة") return { days: null, label: "تم ✔", tone: "done" };
  const d = daysUntil(order.deliveryDate);
  if (d < 0) return { days: d, label: "متأخرة!", tone: "danger" };
  if (d <= 3) return { days: d, label: "اقترب الموعد", tone: "warn" };
  return { days: d, label: "في الميعاد", tone: "ok" };
}

export function materialInfo(m: MaterialItem): AlertInfo {
  if (m.status === "تم الاستلام") return { days: null, label: "تم الاستلام", tone: "done" };
  if (m.status === "ناقص") return { days: daysUntil(m.expectedDate), label: "ناقص!", tone: "danger" };
  const d = daysUntil(m.expectedDate);
  if (d < 0) return { days: d, label: "استلام متأخر", tone: "danger" };
  if (d <= 3) return { days: d, label: "اقترب الموعد", tone: "warn" };
  return { days: d, label: "في الميعاد", tone: "ok" };
}

export function isActiveOrder(o: Order): boolean {
  return o.status !== "مكتملة" && o.status !== "ملغاة";
}

export function currentStageOf(
  orderId: string,
  stages: ProductionStage[],
): { name: string; status: StageStatus } | null {
  const list = stages.filter((s) => s.orderId === orderId);
  if (list.length === 0) return null;
  for (const name of STAGE_PIPELINE) {
    const s = list.find((x) => x.stage === name && x.status !== "مكتملة");
    if (s) return { name: s.stage, status: s.status };
  }
  return { name: "اكتملت جميع المراحل", status: "مكتملة" };
}

export function stageProgress(
  orderId: string,
  stages: ProductionStage[],
): { done: number; total: number; pct: number } {
  const list = stages.filter((s) => s.orderId === orderId);
  const done = list.filter((s) => s.status === "مكتملة").length;
  const total = list.length;
  return { done, total, pct: total === 0 ? 0 : Math.round((done / total) * 100) };
}

// ---------- مؤشرات لوحة المتابعة ----------
export function dashboardStats(data: AppData) {
  const orders = data.orders.filter((o) => o.status !== "ملغاة");
  const active = orders.filter(isActiveOrder);
  const info = orders.map((o) => ({ order: o, alert: deadlineInfo(o) }));
  return {
    totalOrders: orders.length,
    activeOrders: active.length,
    completedOrders: orders.filter((o) => o.status === "مكتملة").length,
    delayed: info.filter((x) => x.alert.tone === "danger").length,
    approaching: info.filter(
      (x) => x.alert.tone === "warn" && isActiveOrder(x.order),
    ).length,
    highPriority: orders.filter((o) => o.priority === "عالية").length,
    wholesale: orders.filter((o) => o.clientType === "جملة").length,
    retail: orders.filter((o) => o.clientType === "قطاعي").length,
    totalPieces: orders.reduce((sum, o) => sum + (o.quantity || 0), 0),
    missingMaterials: data.materials.filter((m) => m.status === "ناقص").length,
    stoppedStages: data.stages.filter((s) => s.status === "متوقفة").length,
    readyForDelivery: orders.filter((o) => o.status === "جاهزة للتسليم").length,
  };
}
